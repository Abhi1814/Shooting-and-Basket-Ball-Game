﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GamePlay : MonoBehaviour {

	public GameObject timerText;
	public GameObject scoreText;
	int roundsShot = 0;
	int enemyKilled = 0;

	public GameObject gameOverPanel;
	public ParticleSystem muzzleFlashParticle;

	bool gameIspaused = false;

	public GameObject bazookaGo;
	public GameObject crossHairGo;

	public Text imageToToggle ;
	public float interval =0.2f ;
	public float startDelay = 1;
	public bool currentstate =true ;
	public bool defaultstate = true ;
	bool isBlinking = false ;

	int gameTime = 120;

	AudioSource gunShotAudioSource ;
	public AudioClip gunShotClip;

	void Start ()
	{
		scoreText.GetComponent<Text> ().text = enemyKilled.ToString () + " / " + roundsShot.ToString ();

		gunShotAudioSource = gameObject.GetComponent<AudioSource> ();

		InvokeRepeating ("changeTimer", 0, 1);
		timerText.GetComponent<Text>().text = gameTime.ToString();


		imageToToggle.enabled = defaultstate;
		//StartBlink();
		//InvokeRepeating ("changeTimer", startDelay, interval);

	}

	public void StartBlinking()
	{
		if (isBlinking) 
		{
			return;
		}
		if (imageToToggle != null)
		{
			isBlinking = true;
			InvokeRepeating ("ToggleState", startDelay, interval * 3 );
		}
	}

	public void ToggleState()
	{
		imageToToggle.enabled = !imageToToggle.enabled;
		//if (clip)
		//
	}

	void changeTimer()
	{
		if (gameTime >= 0) 
		{
			int timeMiniutes = (int)gameTime / 60;
			int timeSeconds = gameTime % 60;
			gameTime = gameTime - 1;

			timerText.GetComponent<Text> ().text = timeMiniutes.ToString ()+":" + timeSeconds.ToString("D2");
		} 
		else 
		{
			Time.timeScale = 0;
			gameIspaused = true;
			gameOverPanel.GetComponent<CanvasGroup> ().alpha = 1;
			gameOverPanel.GetComponent<CanvasGroup> ().interactable = true;
			gameOverPanel.GetComponent<CanvasGroup> ().blocksRaycasts = true;
		}

		if (gameTime < 10) 
		{
			StartBlinking ();
		}
	}

	void shootAction()
	{
		
		gunShotAudioSource.PlayOneShot (gunShotClip);
		muzzleFlashParticle.Emit (1);
		roundsShot = roundsShot + 1;


		Vector2 dir = new Vector2(crossHairGo.transform.position.x, crossHairGo.transform.position.y);
		RaycastHit2D hit = Physics2D.Raycast (Camera.main.transform.position, dir);

		if (hit.collider != null && hit.collider.gameObject != crossHairGo) 
		{
			enemyKilled++ ;
			Destroy (hit.collider.gameObject);
		}



		scoreText.GetComponent<Text> ().text = enemyKilled.ToString () + " / " + roundsShot.ToString ();
	}
	// Update is called once per frame
	void Update ()
	{
		if (!gameIspaused) 
		{
			if (Input.GetKeyUp (KeyCode.Space)) {
				shootAction ();
			}
			bazookaGo.transform.LookAt (crossHairGo.transform);

			float h = Input.GetAxis ("Mouse X") / 2;
			float v = Input.GetAxis ("Mouse Y") / 2;

			Vector3 CrossHairMove = new Vector3 (h, v, 0);
			crossHairGo.transform.Translate (CrossHairMove);

			float x = crossHairGo.transform.position.x;
			float y = crossHairGo.transform.position.y;

			if (x > 7)
				x = 7;
			if (x < -7)
				x = -7;
			if (y > 4)
				y = 4;
			if (y < -4)
				y = -4;

			crossHairGo.transform.position = new Vector3 (x, y, 7.0f);
		}
	}

	public void Restartgame()
	{
		Time.timeScale = 1;
		gameIspaused = false;
		gameOverPanel.GetComponent<CanvasGroup> ().alpha = 0;
		gameOverPanel.GetComponent<CanvasGroup> ().interactable = false;
		gameOverPanel.GetComponent<CanvasGroup> ().blocksRaycasts = false;

		gameTime = 120;
		enemyKilled = 0;
		roundsShot = 0;
		scoreText.GetComponent<Text> ().text = enemyKilled.ToString () + " / " + roundsShot.ToString ();
		changeTimer ();

	}

	public void BackScene()
	{
		SceneManager.LoadScene ("First Scene (Play Quit)");
	}
}
