﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ControlGame : MonoBehaviour {

	public bool paused;

	public Text buttonnext;
	void Start () {
		paused = false;	
	}
	

	void Update () {
		
	}

	public void onPause()
	{
		paused = !paused;

		if (paused) 
		{
			Time.timeScale = 0;
			buttonnext.text = "Resume";
		}
		else if(!paused)
		{
			Time.timeScale = 1;
			buttonnext.text = "Pause";
		}


	}

}
