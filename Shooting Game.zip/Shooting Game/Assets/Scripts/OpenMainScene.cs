﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenMainScene : MonoBehaviour {



	// Use this for initialization
	void Start () {
		
	}


	
	// Update is called once per frame
	void Update () {
		
	}

	public void MainScene()
	{
		SceneManager.LoadScene ("Second Scene (Main)");
	}

	public void ExitScene()
	{
		Application.Quit();
		//UnityEditor.EditorApplication.isPlaying = false;
	}

	public void BackScene()
	{
		SceneManager.LoadScene ("First Scene (Play Quit)");
	}
}
