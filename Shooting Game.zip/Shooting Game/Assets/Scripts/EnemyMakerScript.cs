﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMakerScript : MonoBehaviour {

	public GameObject enemyGo; 
	public Sprite[] myimages ;
	// Use this for initialization
	void Start () {
		InvokeRepeating ("makeAnEnemyAction", 0, 3);
	}



	// Update is called once per frame
	void makeAnEnemyAction()
	{
		GameObject newEnemyGo = (GameObject)Instantiate (enemyGo) as GameObject;
		float x = Random.Range (-6.5f , 6.5f);
		float y = -3;
		float z = 7.1f;

		newEnemyGo.transform.position = new Vector3 (x, y, z);
		newEnemyGo.GetComponent<SpriteRenderer> ().sprite = myimages[Random.Range(0, myimages.Length)];
		newEnemyGo.GetComponent<Rigidbody2D> ().AddForce (Vector3.up * 500);
	}

}
